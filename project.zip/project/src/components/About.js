import React from 'react';

const About = () => {
    return (
        <div>
            <h2>ABout</h2>
        </div>
    );
}

export default About;
